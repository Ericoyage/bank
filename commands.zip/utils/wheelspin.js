const { AttachmentBuilder, EmbedBuilder } = require("discord.js");

const { createCanvas } = require("canvas");
const GIFEncoder = require("gifencoder");
const getRandomColor = () => {
  const letters = "0123456789ABCDEF".split("");
  let color = "#";
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
};

const getRandomColors = (length) => {
  const colors = [];
  for (let i = 0; i < length; i++) {
    colors.push(getRandomColor());
  }
  return colors;
};

const getTextColorFromBackground = (background) => {
  const bg = parseInt(background.substr(1), 16);
  const r = (bg >> 16) & 0xff;
  const g = (bg >> 8) & 0xff;
  const b = bg & 0xff;
  const luma = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  return luma > 130 ? "#000" : "#fff";
};
const easeOutQuad = (t, b, c, d) => -c * ((t = t / d - 1) * t * t * t - 1) + b;

const styles2 = {
  circle: {
    margin: 5,
    fillColor: "#fff",
    strokeColor: "#000",
    strokeWidth: 2,
  },
  options: {
    font: "14px arial black",
    textBaseline: "middle",
    portionStrokeColor: "#000",
    portionStrokeWidth: 1,
  },
  centerDot: {
    fillColor: "#000",
    radius: 5,
  },
  arrow: {
    height: 20,
    width: 10,
    fillColor: "#fff",
    strokeColor: "#000",
    strokeWidth: 2,
  },
};

const createCanvasWheel = (
  canvas,
  ctx,
  options,
  endAngleDegrees,
  totalSteps
) => {
  const cw = canvas.width;
  const ch = canvas.height;
  const cx = cw / 2;
  const cy = ch / 2;
  const radius = Math.min(cw, ch) / 2 - styles2.circle.margin;
  const endAngle = (endAngleDegrees * Math.PI) / 180;
  const portionAngle = (Math.PI * 2) / options.length;
  const optionOffset = portionAngle / 2;

  const colors = getRandomColors(options.length);

  const easing = (step) => easeOutQuad(step, 0, endAngle, totalSteps);

  const drawCicle = () => {
    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, Math.PI * 2);
    ctx.fillStyle = styles2.circle.fillColor;
    ctx.strokeStyle = styles2.circle.strokeColor;
    ctx.lineWidth = styles2.circle.strokeWidth;
    ctx.fill();
    ctx.stroke();

    ctx.setTransform(1, 0, 0, 1, 0, 0);
  };

  const drawOption = (angle, index, option, backgroundColor) => {
    const optionAngle = angle + portionAngle * index;
    const textColor = getTextColorFromBackground(backgroundColor);

    const drawPortion = () => {
      ctx.beginPath();
      ctx.fillStyle = backgroundColor;
      ctx.strokeStyle = styles2.options.portionStrokeColor;
      ctx.lineWidth = styles2.options.portionStrokeWidth;
      ctx.moveTo(cx, cy);
      ctx.arc(
        cx,
        cy,
        radius,
        optionAngle - optionOffset,
        optionAngle + optionOffset,
        false
      );
      ctx.lineTo(cx, cy);
      ctx.fill();
      ctx.stroke();
    };

    const drawText = () => {
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(optionAngle);
      ctx.fillStyle = textColor;
      ctx.font = styles2.options.font;
      ctx.textBaseline = styles2.options.textBaseline;

      const textWidth = Math.min(ctx.measureText(option).width, radius);
      const centeredTextX = (radius - textWidth) / 2;

      ctx.fillText(option, centeredTextX, 0, radius);
      ctx.restore();
    };

    drawPortion();
    drawText();
  };

  const drawOptions = (angle) => {
    const [first, ...rest] = options;
    const orderedOptions = [first, ...rest.reverse()];

    const [firstColor, ...restColors] = colors;
    const orderedColors = [firstColor, ...restColors.reverse()];

    for (let i = 0; i < orderedOptions.length; i++) {
      const option = orderedOptions[i];
      const color = orderedColors[i];
      drawOption(angle, i, option, color);
    }
  };

  const drawCenterDot = () => {
    ctx.beginPath();
    ctx.arc(cw / 2, ch / 2, styles2.centerDot.radius, 0, Math.PI * 2);
    ctx.fillStyle = styles2.centerDot.fillColor;
    ctx.fill();
  };

  const drawArrow = () => {
    const initialX = cw - styles2.circle.margin;
    const initialY = cy - styles2.arrow.width;
    ctx.beginPath();
    ctx.moveTo(initialX, initialY);
    ctx.lineTo(initialX, initialY + styles2.arrow.width * 2);
    ctx.lineTo(initialX - styles2.arrow.height, initialY + styles2.arrow.width);
    ctx.closePath();
    ctx.fillStyle = styles2.arrow.fillColor;
    ctx.strokeStyle = styles2.arrow.strokeColor;
    ctx.lineWidth = styles2.arrow.strokeWidth;
    ctx.fill();
    ctx.stroke();
  };

  const draw = (step) => {
    const angle = easing(step);

    ctx.translate(cx, cy);
    ctx.rotate(angle);
    ctx.clearRect(0, 0, cw, ch);

    drawCicle();
    drawOptions(angle);
    drawCenterDot();
    drawArrow();
  };

  const rotate = (step) => {
    draw(step);
  };

  const getOptionByStep = (step) => {
    const angle = easing(step) + optionOffset;
    const optionIndex = Math.floor(angle / portionAngle) % options.length;
    return {
      option: options[optionIndex],
      color: colors[optionIndex],
    };
  };

  const getColorByStep = (step) => {
    const angle = easing(step) + optionOffset;
    const optionIndex = Math.floor(angle / portionAngle) % options.length;
    return {
      option: options[optionIndex],
      color: colors[optionIndex],
    };
  };

  return {
    rotate,
    getOptionByStep,
    getColorByStep,
  };
};

const generateSpinWheel = (
  options,
  angle,
  duration,
  frameDelayMs,
  canvasWidth,
  canvasHeight,
  lastFrameDurationMs
) => {
  const encoder = new GIFEncoder(canvasWidth, canvasHeight);
  encoder.start();
  encoder.setRepeat(0);
  encoder.setDelay(frameDelayMs);
  encoder.setQuality(10);
  encoder.setTransparent("#fff");

  const canvas = createCanvas(canvasWidth, canvasHeight);
  const ctx = canvas.getContext("2d");

  const wheel = createCanvasWheel(canvas, ctx, options, angle, duration);

  for (let i = 0; i < duration; i++) {
    wheel.rotate(i);
    encoder.addFrame(ctx);
  }

  for (let i = 0; i < lastFrameDurationMs; i++) {
    encoder.addFrame(ctx);
  }

  encoder.finish();

  const selectedOption = wheel.getOptionByStep(duration);

  return {
    getGif: () => encoder.out.getData(),
    getLastFrame: () => canvas.toBuffer(),
    selectedOption: selectedOption.option,
    selectedOptionColor: selectedOption.color,
  };
};

module.exports = generateSpinWheel;
const { Message, AttachmentBuilder, EmbedBuilder } = require("discord.js");
const { Canvas, loadImage } = require("canvas-constructor/napi-rs");
const { EventEmitter } = require("node:events");
const { Flood } = require("discord-gamecord");
const { QuickDB } = require("quick.db");
const parse = require("parse-ms");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return false;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let times = await db.tableAsync("times");
    let bank = await db.tableAsync("bank");

    if (
      (await times.get(`لون_${msg.guild.id}_${msg.author.id}`)) &&
      (await times.get(`لون_${msg.guild.id}_${msg.author.id}`)) >
        new Date().getTime()
    )
      return msg.reply({
        allowedMentions: { repliedUser: false },
        content: `:x: | \`${
          parse(
            (await times.get(`لون_${msg.guild.id}_${msg.author.id}`)) -
              new Date().getTime()
          ).minutes
        } minutes, ${
          parse(
            (await times.get(`لون_${msg.guild.id}_${msg.author.id}`)) -
              new Date().getTime()
          ).seconds
        } seconds\` , أنتظر لاهنت`,
      });
    const Game = new Flood({
      message: msg,
      isSlashGame: false,
      embed: {
        title: "وحد جميع المكعبات الى لون واحد بأقل عدد محاولات واربح 5000",
        color: "#5865F2",
      },
      difficulty: 13,
      timeoutTime: 60000,
      buttonStyle: "PRIMARY",
      emojis: ["🟥", "🟦", "🟧", "🟪", "🟩"],
      winMessage: "الف مبروك فزت ب 5000 الاف:)",
      loseMessage: "لقد خسرت ",
      playerOnlyMessage: "فقط {player} يقدر يلعب.",
    });

    Game.startGame();
    Game.on("gameOver", async (result) => {
      if (result.result == "win") {
        let carncy = (await bank.get(`money_${msg.author.id}`)) ?? "0";
        await bank.set(`money_${msg.author.id}`, String(Number(carncy) + 5000));
      }
    });
    times.set(
      `لون_${msg.guild.id}_${msg.author.id}`,
      new Date().getTime() + 300000
    );
  }
};
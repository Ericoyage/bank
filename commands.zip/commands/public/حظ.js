const { Message, AttachmentBuilder, EmbedBuilder } = require("discord.js");
const { EventEmitter } = require("node:events");
const { QuickDB } = require("quick.db");
const {
  Canvas,
  loadImage,
  GlobalFonts,
} = require("canvas-constructor/napi-rs");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Cairo.ttf", "Cairo");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Cairo.ttf", "Cairo");
const parse = require("parse-ms");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return false;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let base = await db.tableAsync("base");
    let bank = await db.tableAsync("bank");
    let times = await db.tableAsync("times");

    let isEmbed = (await base.get(`e_${msg.guild.id}`)) ?? false;
    let embedColor = (await base.get(`eColor_${msg.guild.id}`)) ?? "#FFFFFF";
    let imageURL = process.cwd() + "/default/main.png";
    if (
      (await times.get(`حظ_${msg.guild.id}_${msg.author.id}`)) &&
      (await times.get(`حظ_${msg.guild.id}_${msg.author.id}`)) >
        new Date().getTime()
    )
      return msg.reply({
        allowedMentions: { repliedUser: false },
        content: `:x: | \`${
          parse(
            (await times.get(`حظ_${msg.guild.id}_${msg.author.id}`)) -
              new Date().getTime()
          ).minutes
        } minutes, ${
          parse(
            (await times.get(`حظ_${msg.guild.id}_${msg.author.id}`)) -
              new Date().getTime()
          ).seconds
        } seconds\` : أنتظر لاهنت`,
      });

    let amount = Math.floor(Math.random() * 15000) + 1000;
    let current = (await bank.get(`money_${msg.author.id}`)) ?? "0";
    await bank.set(`money_${msg.author.id}`, String(Number(current) + amount));
    async function createCanvas() {
      const image = await loadImage(imageURL);

      const sacandStage = new Canvas(700, 250)
        .printImage(image, 0, 0, 700, 250)
        .setColor("#000000")
        .setTextFont(" 28px Impact")
        .printText(msg.author.username, 80, 180)
        .printText(amount.toString() + "$", 80, 220)
        .setTextAlign("left")
        .setColor("#ffffff")
        .setTextFont("bold 48px Cairo")
        .printText("عملية ايداع", 480, 140)
        .setTextFont("bold 24px Cairo")
        .printText(". حظك هالوقت ", 405, 180)
        .pngAsync();
      let tabel = await db.tableAsync("base");
      let imageB = await tabel.get(`image_${msg.guild.id}`);

      if (imageB) {
        const lastImage = await loadImage(imageB);
        const last = new Canvas(700, 250)
          .printImage(lastImage, 0, 0, 700, 250)
          .setGlobalAlpha(0.9)
          .printImage(await loadImage(await sacandStage), 0, 0, 700, 250)
          .pngAsync();

        return await last;
      } else return await sacandStage;
    }
    let resultImage = new AttachmentBuilder(await createCanvas(), {
      name: "7lm.png",
    });
    times.set(
      `حظ_${msg.guild.id}_${msg.author.id}`,
      new Date().getTime() + 300000
    );
    let msi = await msg.reply({ files: [resultImage] });
    if (isEmbed)
      msi.edit({
        embeds: [
          new EmbedBuilder()
            .setColor(embedColor)
            .setImage("attachment://7lm.png"),
        ],
      });
  }
};

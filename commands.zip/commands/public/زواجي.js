const { Message, AttachmentBuilder, EmbedBuilder } = require("discord.js");
const { EventEmitter } = require("node:events");
const { QuickDB } = require("quick.db");
const {
  Canvas,
  loadImage,
  GlobalFonts,
} = require("canvas-constructor/napi-rs");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Cairo.ttf", "Cairo");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Emojis.ttf", "Emojis");
const parse = require("parse-ms");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return false;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let zwagat = await db.tableAsync("zwagat");
    let list = await zwagat.get("list") ?? [];

    let object = list.find(
      (zwag) => zwag.man == msg.author.id || zwag.woman == msg.author.id
    );
    if (!object) return msg.reply("أنت غير متزوج");
    msg.reply({
      embeds: [
        {
          thumbnail: {
            url: "https://media.discordapp.net/attachments/1105475002784034908/1124703353973264414/wedding-couple.png?width=554&height=554",
          },
          description: `**:person_in_tuxedo: <@${object.man}> | :person_with_veil: <@${object.woman}>**\nمهر: ${object.mahr}\n\nتم الزواج في تاريخ: ${object.date}`
        },
      ],
    });
  }
};

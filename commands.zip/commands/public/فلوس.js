const { Message, AttachmentBuilder, EmbedBuilder } = require("discord.js");
const { EventEmitter } = require("node:events");
const { QuickDB } = require("quick.db");
const { Canvas, loadImage } = require("canvas-constructor/napi-rs");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }

  isAdmin() {
    return false;
  }

  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let base = await db.tableAsync("base");
    let bank = await db.tableAsync("bank");
    let topTen = (await bank.all())
      .sort(({ value: v1 }, { value: v2 }) => Number(v2) - Number(v1))
      .findIndex((value) => value.id.split("money_").join("") == msg.author.id);
    topTen = topTen + 1;
    let isEmbed = (await base.get(`e_${msg.guild.id}`)) ?? false;
    let embedColor = (await base.get(`eColor_${msg.guild.id}`)) ?? "#FFFFFF";
    let imageURL = process.cwd() + "/default/فلوس.png";

    async function createCanvas() {
      const image = await loadImage(imageURL);
      const avatar = await loadImage(msg.author.avatarURL({ size: 2048 }));
      const firstStage = new Canvas(700, 250)
        .printImage(image, 0, 0, 700, 250)
        .createRoundedClip(30, 35, 180, 180, 360)
        .setColor("#000000")
        .createCircularClip(120, 125, 90)
        .printImage(avatar, 30, 35, 180, 180)
        .pngAsync();

      let carrcany = (await bank.get(`money_${msg.author.id}`)) ?? "0"; // Initialize carrcany variable

      const stageImage = await loadImage(await firstStage);
      const sacandStage = new Canvas(700, 250)
        .printImage(stageImage, 0, 0, 700, 250)
        .setColor("#00000")
        .setTextFont("28px Impact")
        .printText(msg.author.username, 230, 90)
        .printText("Top: " + topTen, 230, 130)
        .printText(String(Number(carrcany).toFixed(0)) + "$", 280, 180)
        .pngAsync();

      let tabel = await db.tableAsync("base");
      let imageB = await tabel.get(`image_${msg.guild.id}`);

      if (imageB) {
        const lastImage = await loadImage(imageB);
        const last = new Canvas(700, 250)
          .printImage(lastImage, 0, 0, 700, 250)
          .setGlobalAlpha(0.9)
          .printImage(await loadImage(await sacandStage), 0, 0, 700, 250)
          .pngAsync();

        return await last;
      } else return await sacandStage;
    }

    let resultImage = new AttachmentBuilder(await createCanvas(), {
      name: "7lm.png",
    });

    let msi = await msg.reply({ files: [resultImage] });

    if (isEmbed)
      msi.edit({
        embeds: [
          new EmbedBuilder().setColor(embedColor).setImage("attachment://7lm.png"),
        ],
      });
  }
};

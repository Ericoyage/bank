const { Message, AttachmentBuilder, EmbedBuilder } = require("discord.js");
const { EventEmitter } = require("node:events");
const { QuickDB } = require("quick.db");
const { Canvas, loadImage } = require("canvas-constructor/napi-rs");
const parse = require("parse-ms");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return false;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let base = await db.tableAsync("base");
    let bank = await db.tableAsync("bank");
    let times = await db.tableAsync("times");
    msg.reply({
      embeds: [
        {
          author: {
            name: "أغنى 10 أعضاء بالسيرفر 📋",
            icon_url: msg.guild.iconURL(),
          },
          thumbnail: {
            url: msg.guild.iconURL(),
          },
          description: `${(await bank.all())
            .sort(({ value: v1 }, { value: v2 }) => Number(v2) - Number(v1))
            .map(
              (value, index) =>
                `**#${index + 1}** | <@${
                  value.id.split("money_").join("")
                }> : \`${value.value}$\``
            )
            .slice(0, 9)
            .join("\n")}\n\n**ترتيبك في القائمة: \`${
            (await bank.all())
              .sort(({ value: v1 }, { value: v2 }) => Number(v2) - Number(v1))
              .findIndex(
                (value) => value.id.split("money_").join("") == msg.author.id
              ) + 1
          }\`**`,
        },
      ],
    });
  }
};

const { Message, Embed, EmbedBuilder } = require("discord.js");
const { QuickDB } = require("quick.db");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return true;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let mods = await db.tableAsync("mods");
    let modsArray = [];
    (await mods.all()).forEach(({ id }) => {
      modsArray.push(id);
    });

    msg.reply({
      allowedMentions: { repliedUser: false },
      embeds: [
        {
          thumbnail: {
            url: msg.guild.iconURL(),
          },
          author: {
            name: "**قائمة المدراء بالسيرفر:**",
            icon_url: msg.guild.iconURL(),
          },
          description: modsArray
            .map((id, index) => `**#${index + 1}** : <@!${id}>`)
            .join("\n"),
        },
      ],
    });
  }
};
